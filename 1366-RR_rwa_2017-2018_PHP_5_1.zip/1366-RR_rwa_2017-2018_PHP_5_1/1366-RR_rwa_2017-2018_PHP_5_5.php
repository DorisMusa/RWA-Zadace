<?php
function jmbg($x){

$a;
$spol="Zenski";
$mjesto="a";
	if(strlen($x)!= 13){
	echo "Niste unijeli 13 znamenki";
	return false;
	}
	else if(substr($x,2,2)>12 || substr($x,0,2)==0 || substr($x,3,1)==0 || substr($x,7,2)<10 || substr($x,7,2)>19)
	{
	echo "Niste ispravno unijeli JMBG";
 	return false;
 	}

if((substr($x,2,2)==4 || substr($x,2,2)==6 || substr($x,2,2)==9 || substr($x,2,2)==11) && substr($x,0,2)>30)
{
echo "Niste ispravno unijeli JMBG";
 	return false;
}
if((substr($x,2,2)==1 || substr($x,2,2)==3 || substr($x,2,2)==5 || substr($x,2,2)==7 || substr($x,2,2)==8 || substr($x,2,2)==10 || substr($x,2,2)==12) && substr($x,0,2)>31)
{
echo "Niste ispravno unijeli JMBG";
 	return false;
}
if(substr($x,2,2)==2 && substr($x,0,2)>29)
{
echo "Niste ispravno unijeli JMBG";
 	return false;
}

	if(substr($x,4,1)==0)
	$a=2;
	else $a=1;

if(substr($x,9,3)<=499)
	$spol="Muski";

if(substr($x,7,2)==10)
$mjesto="Banja Luka";
else if(substr($x,7,2)==11)
$mjesto="Bihac";
else if(substr($x,7,2)==12)
$mjesto="Doboj";
else if(substr($x,7,2)==13)
$mjesto="Gorazde";
else if(substr($x,7,2)==14)
$mjesto="Livno";
else if(substr($x,7,2)==15)
$mjesto="Mostar";
else if(substr($x,7,2)==16)
$mjesto="Prijedor";
else if(substr($x,7,2)==17)
$mjesto="Sarajevo";
else if(substr($x,7,2)==18)
$mjesto="Tuzla";
else $mjesto="Zenica";
$dan=substr($x,0,2);
$mjesec=substr($x,2,2);
$godina=substr($x,4,3);
echo "Datum rodjenja: $dan.$mjesec.$a$godina.<br/>Spol: $spol<br/>Mjesto: $mjesto";
 return true ; 
}
jmbg("0106995155081");
?>
