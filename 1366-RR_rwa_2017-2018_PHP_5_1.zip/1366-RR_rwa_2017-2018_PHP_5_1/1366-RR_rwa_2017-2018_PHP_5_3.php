<?php
function faktorijel($n){
$a=1;
while($n>0)
{
$a*=$n;
$n--;
}
return $a;
} 

echo "Table of Factorials <br/><br/>";
$n=9;
$fakt;
for($i=1; $i<=$n; $i++){
$fakt=faktorijel($i);
echo "$i! = $fakt <br/>";
}
?>
