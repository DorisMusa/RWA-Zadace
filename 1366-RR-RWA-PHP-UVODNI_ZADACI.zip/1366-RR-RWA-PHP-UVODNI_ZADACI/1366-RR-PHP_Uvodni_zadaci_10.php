<?php
$a=52.5;
$b=10.475;
$pov_pravokutnik=$a*$b;
echo "Povrsina pravokutnika sirine $a i duzine $b iznosi $pov_pravokutnik.";  
?>