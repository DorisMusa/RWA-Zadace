<?php
$suma=0;
for($i=1; $i<=100; $i++)
{
$suma+=$i;
}
echo "Suma prvih 100 prirodnih brojeva koristenjem for petlje je $suma.";

?>