<?php
$grad=array(1995 => 54000, 1997 => 58810, 1998 => 62154, 2000 => 60124, 2002 => 63114);

$br=0;
$suma=0;
$prosjek=0;
$godina_najveceg_broja_stanovnika=0;
$max_stanovnika=0;

foreach($grad as $key=>$value){
$suma+=$value;
$br++;
if ($value>$max_stanovnika){
$max_stanovnika=$value;
$godina_najveceg_broja_stanovnika=$key;
}
}
$prosjek=$suma/$br;

echo "Prosjecan broj stanovnika kroz sve godine je $prosjek.<br/>";
echo "Najvise stanovnika je bilo $godina_najveceg_broja_stanovnika. godine.<br/>";
echo "Mjerenje se provodilo $br godina.<br/>";
?>